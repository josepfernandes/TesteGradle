rootProject.name = "gradle-springboot-kotlin"

include("library-hello-factory")
include("library-world-factory")
include("app-springboot-helloworld")
