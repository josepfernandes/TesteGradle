
// This file is intentionally empty.
// Subproject-specific configuration is done in the root project build.gradle.kts file.
